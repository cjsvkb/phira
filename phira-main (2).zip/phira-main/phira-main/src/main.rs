fn main() {
    phira::quad_main();
}
