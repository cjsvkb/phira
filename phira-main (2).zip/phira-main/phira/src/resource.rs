prpr_l10n::tl_file!("resource" rtl);
